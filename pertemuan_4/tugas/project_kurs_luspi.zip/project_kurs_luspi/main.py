from tabulate import tabulate
from kurs import kurs
from konverter import konversi

print("=== KONVERTER MATA UANG ===")

tabel = []
for kode, nilai in kurs.items():
    if kode != "IDR":
        tabel.append([kode, f"{nilai:,}".replace(",",".")])

print(tabulate(tabel, headers=["Kode", "Kurs"], tablefmt="grid"))

dari = input("Dari (IDR/USD/EUR/SGD/JPY): ")
dari = dari.upper()

ke = input("Ke (IDR/USD/EUR/SGD/JPY): ")
ke = ke.upper()

jumlah = float(input("Jumlah: "))
hasil = konversi(jumlah, dari, ke)

if dari == "IDR":
    print(f"Rp {jumlah:,.0f} = {hasil:.2f} {ke}".replace(",","."))
elif ke == "IDR":
    print(f"{jumlah:.2f} {dari} = Rp {hasil:,.0f}".replace(",","."))
else:
    print(f"{jumlah:.2f} {dari} = {hasil:.2f} {ke}".replace(",","."))