from kurs import kurs

def indo_ke_duit_lain(jumlah_idr, kode_tujuan):
    return jumlah_idr / kurs[kode_tujuan]

def duit_lain_ke_indo(jumlah, kode_asal):
    return jumlah * kurs[kode_asal]

def konversi(jumlah, dari, ke):
    if dari == "IDR":
        return indo_ke_duit_lain(jumlah, ke)
    elif ke == "IDR":
        return duit_lain_ke_indo(jumlah, dari)
    else:
        idr = duit_lain_ke_indo(jumlah, dari)
        return indo_ke_duit_lain(idr, ke)