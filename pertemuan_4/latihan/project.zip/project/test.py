from colorama import Fore, Back, Style, init
init()

print("balonku ada lima")
print("rupa rupa warnanya")
print(Fore.RED +  'Merah ')
print(Fore.YELLOW + 'kuning')
print(Style.DIM + 'kelabu')

